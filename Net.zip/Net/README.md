# LSPNetwork

[![CI Status](https://img.shields.io/travis/li.zt/LSPNetwork.svg?style=flat)](https://travis-ci.org/li.zt/LSPNetwork)
[![Version](https://img.shields.io/cocoapods/v/LSPNetwork.svg?style=flat)](https://cocoapods.org/pods/LSPNetwork)
[![License](https://img.shields.io/cocoapods/l/LSPNetwork.svg?style=flat)](https://cocoapods.org/pods/LSPNetwork)
[![Platform](https://img.shields.io/cocoapods/p/LSPNetwork.svg?style=flat)](https://cocoapods.org/pods/LSPNetwork)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

LSPNetwork is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'LSPNetwork'
```

## 导入头文件
```swift
import LSPNetwork
```
## 功能概述
### 1.2.0
+ baseUrl、公参、公Header设置
+ 网络请求加解密
+ GET/POST等方法支持
+ 上传文件
+ 下载文件
+ 网络请求超时设置
+ 网络请求失败3次重试设置
+ 网络请求的取消、暂停、恢复

## 举例
```swift

//使用网络请求前先进行网络配置
struct ConfigNetDemo: LSConfigNetProtocol{
    let aes_Key = "b79784a829fec55d"
    let aes_iv  = "e165666005912d7c"
    var baseUrlStr: String? = "https://test-api2-office.lanshan.com"  //公共baseUrl，  如接口调用时，url传入的非http开头的url,自动拼接baseUrlStr.
    
    //如有公共参数、公共headers，在此实现
    
    //定义加解密策略。无加解密下面两方法可不实现
    public func commonEncrypt(_ paramStr: String?)->String {  
        
        return aes128Encrypt(paramStr!)
    }
    public func commonDecrypt(_ result: String?)->String{
        if let str = result {
            return aes128Decrypt(str)
        }
        return ""
    }
    
    func aes128Encrypt(_ plainText: String) -> String {
        var encryptedText = ""
        do {
            let aes = try AES(key: aes_Key.bytes, blockMode: CBC(iv: aes_iv.bytes), padding: .pkcs5)
            let encrypted = try aes.encrypt(plainText.bytes)
            let encryptedBase64 = encrypted.toBase64()
            encryptedText = encryptedBase64 ?? ""
        } catch  {

        }
        return encryptedText
    }
    
    func aes128Decrypt(_ base64String: String) -> String {
        var decryptedText = ""
        do {
            let aes = try AES(key: aes_Key.bytes, blockMode: CBC(iv: aes_iv.bytes), padding: .pkcs5)
            decryptedText = try base64String.decryptBase64ToString(cipher: aes)
        } catch  {
            
        }
        return decryptedText
    }
}
LSNT.config = ConfigNetDemo()

parameters：类型->[String: Any],可为nil
headers: 请求头，默认application/json,可为nil

// POST Demo
//参数详情见api
let fileList = "/file/list" //列表
let params = ["uniqueCode": "315BBF99953645189E86604310D5543A"]
LSNT.POST(url: fileList, parameters: params,headers: ["token":token],isRetry: true, isEncrypt: true).success { (response) in
    debugPrint("列表查询成功\(response)")
}.failed { (error) in
    debugPrint("列表查询失败\(error.message)")
}
//Upload Demo
let datas = [LSMultipartData(data: data, name: "file", fileName: "ceshi.ott",
                             type: LSDataMimeType.FormData)]

LSNT.UPLOAD(url: upload_files, parameters: nil,headers: ["token":token], datas: datas).success { (response) in
    debugPrint("上传成功\(response)")
}.progress { (progress) in
    debugPrint("上传进度\(progress)")
}.failed { (error) in
    debugPrint("上传失败\(error)")
}

//Download Demo
LSNT.DOWN(url: "https://cdn-office.lanshan.com/office_document_test/teamwork/ffc6223c24f34bf19e488df2372ab3cd/45CE74FA8E0D42DDA047EBC0D92834E92063347515.doc", parameters: nil ).success { (response) in
    print(response)
}.progress { (prg) in
    print(prg)
}.failed { (error) in
    print(error.message)
}
```
同时支持接口请求的取消Cancel()、暂停Suspend()、恢复Resume()操作

## 更新记录
### 1.2.5(2021-07-09)
修改request接口，get请求时，参数为nil改为不带公参

### 1.2.4(2021-07-02)
修改httpBody逻辑，区分json/urlencoding编码
### 1.2.3(2021-07-02)
增加参数encoding功能
修复Header为空问题

### 1.2.2(2021-07-02)
修改加密请求, 原返回String改为Dictionary, 与不加密返回一致


## Author

li.zt, lizhentao@021.com

## License

LSPNetwork is available under the MIT license. See the LICENSE file for more info.
