//
//  LSConfigNet.swift
//  RFNet
//
//  Created by zrf on 2021/6/25.
//

import Foundation

//MARK: 专属网络配置类
public protocol LSConfigNetProtocol {
    var baseUrlStr: String? {get set}
    func commonParams()->[String:Any]?  //公共参数配置
    func commonHeaders()->[String:String]?  //公共Header配置
    func commonEncrypt(_ paramStr: String?)->String  //json string参数加密.
    func commonDecrypt(_ result: String?)->String  //返回结果解密.
}
extension LSConfigNetProtocol{
    public func commonParams() -> [String:Any]? {
        var parameters = [String:Any]()
        if let aclass = NSClassFromString("XMParamFactory") {
            if let myClass = aclass as? NSObject.Type {
                if let commonParams = myClass.perform(NSSelectorFromString("java_php_params"))?.takeUnretainedValue() as? [String: Any] {
                    parameters.netMerge(dict: commonParams)
                }
            }
        }
        
        return parameters  //默认无公共参数
    }
    public func commonHeaders()->[String:String]?{
        return nil
    }
    //加解密数据。 
    public func commonEncrypt(_ paramStr: String?)->String {
        return ""
    }
    public func commonDecrypt(_ result: String?)->String{
        return ""
    }
}
