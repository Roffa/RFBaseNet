//
//  LSAPI.swift
//  LSNetwork
//
//  Created by li.zt on 2021/5/6.
//

import Foundation

/// Type representing HTTP methods.
public enum LSHTTPMethod {
    /// Common HTTP methods.
    case delete, get, patch, post, put
}

/// API interface protocol
public protocol LSAPIProtocol {
    /// API URL address
    var url: String { get }
    /// API description information
    var description: String { get }
    /// API additional information, eg: Author | Note...
    var extra: String? { get }
    /// Type representing HTTP methods.
    var method: LSHTTPMethod { get }
}

/// Extension method
public extension LSAPIProtocol {

    /// 根据`LSAPIProtocol`进行一个网络请求
    ///
    /// - Parameters:
    ///   - parameters: `nil` by default.
    ///   - headers: `HTTPHeaders` value to be added to the `URLRequest`. `nil` by default.
    ///   - success: Successful response
    ///   - failed: Failed response
    ///
    func fetch(_ parameters: [String: Any]? = nil, headers: [String: String]? = nil, success: LSSuccessClosure?, failed: LSFailedClosure?) {
        let task = LSNT.fetch(self, parameters: parameters, headers: headers)
        if let s = success {
            task.success(s)
        }
        if let f = failed {
            task.failed(f)
        }
    }

    /// 根据`LSAPIProtocol`进行一个网络请求
    ///
    /// - Parameters:
    ///   - parameters: `nil` by default.
    ///   - headers: `HTTPHeaders` value to be added to the `URLRequest`. `nil` by default.
    ///
    func fetch(_ parameters: [String: Any]? = nil, headers: [String: String]? = nil) -> LSRequest {
        LSNT.fetch(self, parameters: parameters, headers: headers)
    }
}

/// 为了`LSAPIProtocol`给`LSNetworking`扩展的网络请求方法
public extension LSNetworking {
    /// Creates a request, for `LSAPIProtocol`
    ///
    /// - note: more see: `self.request(...)`
    @discardableResult
    func fetch(_ api: LSAPIProtocol, parameters: [String: Any]? = nil, headers: [String: String]? = nil) -> LSRequest {
        let task = sessionManager.request(url: api.url, method: api.method, parameters: parameters, headers: headers)
        task.description = api.description
        task.extra = api.extra
        return task
    }
}


