//
//  LSNetworking.swift
//  LSNetwork
//
//  Created by li.zt on 2021/5/6.
//

import UIKit
import  Alamofire
/// `LSNetworking`网络请求主类
public class LSNetworking {
    /// For singleton pattern
    public static let shared = LSNetworking()

    /// `Session` creates and manages Alamofire's `Request` types during their lifetimes.
    public let sessionManager = LSRequest()

    /// Network reachability manager, The first call to method `startMonitoring()` will be initialized.
    var reachability: LSNetworkStatus?
    public var config: LSConfigNetProtocol?  //公共参数配置
    
    public enum LSEncoding{
        case jsonEncoding   //对应 ContentType= Application/json
        case urlEncoding   //对应 ContentType= application/x-www-form-urlencoded; charset=utf-8
    }
    
    
    /// Creates a GET request
    ///
    /// - note: more see: `LSRequest`
    @discardableResult
    public func GET(url: String, parameters: [String: Any]? = nil, headers: [String: String]? = nil,
                    encoding:LSEncoding = .jsonEncoding,
                        isRetry:Bool = false, isEncrypt:Bool=false, timeout: TimeInterval = 55) -> LSRequest {
        
        sessionManager.request(url: url, method: .get, parameters: parameters, headers: headers, encoding: convertAFEncoding(encoding), isRetry: isRetry,isEncrypt:isEncrypt, timeout: timeout)
    }

    /// 加密POST
    /// - Parameters:
    ///   - url: 请求地址
    ///   - parameters: 参数
    ///   - headers: 请求头，默认application/json
    ///   - httpBody: 参数是否以请求体的方式提交
    /// - Returns: LSRequest
//    deprecate POST_EN 使用POST方法
//    @discardableResult
//    public func POST_EN(url: String,headers: [String: String]? = nil, httpBody:String? = nil, isEncrypt:Bool=false) -> LSRequest {
//        sessionManager.request_EN(url: url, method: .post, headers: headers,httpBody: httpBody)
//    }
    /// POST
    /// - Parameters:
    ///   - url: 请求地址
    ///   - parameters: 参数
    ///   - headers: 请求头，默认application/json
    ///   - isRetry: 是否失败重试3次
    ///   - isEncrypt: 是否加密
    ///   - timeout：超时时间，默认为55秒
    /// - Returns: LSRequest
    /// 
    @discardableResult
    
    public func POST(url: String, parameters: [String: Any]? = nil, headers: [String: String]? = nil, encoding:LSEncoding = .jsonEncoding, isRetry:Bool = false, isEncrypt:Bool=false, timeout: TimeInterval = 55) -> LSRequest {
        sessionManager.request(url: url, method: .post, parameters: parameters, headers: headers, encoding: convertAFEncoding(encoding), isRetry: isRetry,isEncrypt:isEncrypt, timeout: timeout)
    }

    /// Creates a POST request for Upload data
    ///
    /// - note: more see: `LSRequest`
    @discardableResult
    public func UPLOAD(url: String, parameters: [String: String]? = nil, headers: [String: String]? = nil,
                       datas: [LSMultipartData]? = nil, isRetry:Bool=false, timeoutInterval:TimeInterval = 55) -> LSRequest {
        guard datas != nil else {
            return sessionManager.request(url: url, method: .post, parameters: parameters, headers: headers,  isRetry:isRetry, timeout: timeoutInterval)
        }
        return sessionManager.upload(url: url, parameters: parameters, datas: datas!, headers: headers,isRetry: isRetry)
    }

    /// Creates a GET or POST  request for Upload data
    ///
    /// - note: more see: `LSRequest`
    @discardableResult
    public func DOWN(url: String, parameters: [String: String]? = nil, method: LSHTTPMethod = .get, headers: [String: String]? = nil,
                     isRetry: Bool = false,
                     isEncrypt:Bool=false,
                     timeoutInterval:TimeInterval = 55) -> LSRequest {
       
        return sessionManager.download(url: url, method: method, parameters: parameters, headers: headers,  isRetry: isRetry, isEncrypt: isEncrypt, timeout: timeoutInterval)
    }
   
}

extension LSNetworking{
    fileprivate func convertAFEncoding(_ encode: LSEncoding) -> ParameterEncoding{
        switch encode {
            case .jsonEncoding:
                return JSONEncoding.default
            case .urlEncoding:
                return URLEncoding.default
        }
    }
    
}
