//
//  LSRequestAgent.swift
//  LSNetwork
//
//  Created by li.zt on 2021/4/28.
//

import UIKit

class LSRequestAgent: NSObject {

}
