//
//  LSNetworkMonitor.swift
//  LSNetwork
//
//  Created by li.zt on 2021/4/28.
//  网络监听类

import UIKit
import Alamofire


/// Defines the various states of network reachability.
public enum LSReachabilityStatus {
    /// It is unknown whether the network is reachable.
    case unknown
    /// The network is not reachable.
    case notReachable
    /// The connection type is either over Ethernet or WiFi.
    case ethernetOrWiFi
    /// The connection type is a cellular connection.
    case cellular
}
/// `LSNetworkStatus`网络状态
public class LSNetworkStatus {
    
    public static let shared = LSNetworkStatus()

    public let manager = NetworkReachabilityManager.init()
    
    public static let `default` = NetworkReachabilityManager.default
    
    /// Starts monitoring for changes in network reachability status.
    public func netWorkReachability(reachabilityStatus: @escaping(LSReachabilityStatus)->Void){
     
        
        manager?.startListening(onQueue: .main, onUpdatePerforming: { [unowned self] (status) in
            
            switch status {
            case .notReachable:
                reachabilityStatus(.notReachable)
            case .unknown:
                reachabilityStatus(.unknown)
            case .reachable(.ethernetOrWiFi):
                 reachabilityStatus(.ethernetOrWiFi)
            case .reachable(.cellular):
                reachabilityStatus(.cellular)
            }
        })
        
    }

    /// Stops monitoring for changes in network reachability status.
    public func stopMonitoring() {
        guard manager != nil else { return }
        manager?.stopListening()
    }
    
}

