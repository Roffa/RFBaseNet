//
//  LSNetworkingError.swift
//  LSNetwork
//
//  Created by li.zt on 2021/5/6.
//

import UIKit

public class LSNetworkingError: NSObject {
    /// 错误码
    @objc public var code = -1
    /// 错误描述
    @objc public var message: String

    init(code: Int, desc: String) {
        self.code = code
        self.message = desc
        super.init()
    }
}
