//
//  LSRequest.swift
//  LSNetwork
//
//  Created by li.zt on 2021/4/28.
//

import UIKit
import Alamofire

/// Closure type executed when the request is successful
public typealias LSSuccessClosure = (_ JSON: Any) -> Void
/// Closure type executed when the request is failed
public typealias LSFailedClosure = (_ error: LSNetworkingError) -> Void
/// Closure type executed when monitoring the upload or download progress of a request.
public typealias LSProgressHandler = (Progress) -> Void

/// RequestTask
public class LSRequest: Equatable {

    /// Alamofire.DataRequest
    public var request: Alamofire.Request?
    
    private(set) var taskQueue = [LSRequest]()
    
    var sessionManager: Alamofire.Session!
    

    /// API description information. default: nil
    var description: String?
    /// API additional information, eg: Author | Note...,  default: nil
    var extra: String?
    /// The newwork status, `.unknown` by default, You need to call the `startMonitoring()` method
    var networkStatus: LSReachabilityStatus = .unknown
    /// request response callback
    private var successHandler: LSSuccessClosure?
    /// request failed callback
    private var failedHandler: LSFailedClosure?
    /// `ProgressHandler` provided for upload/download progress callbacks.
    private var progressHandler: LSProgressHandler?

    
     init() {
        let config = URLSessionConfiguration.af.default

//        设置超时时间过短，每个接口请求会取此处设置的时间与request设置的时间的最小值
//        config.timeoutIntervalForRequest = 60  // Timeout interval
//        config.timeoutIntervalForResource = 60  // Timeout interval
        sessionManager = Alamofire.Session(configuration: config)
        
    }
    
    /// - Parameters:
    ///   - method: `LSHTTPMethod` for the `URLRequest`. `.get` by default.
    ///   - parameters: `nil` by default.
    ///   - headers: `HTTPHeaders` value to be added to the `URLRequest`. `nil` by default.
    ///   - isRetry: 是否失败重试3次
    ///   - isEncrypt: 是否加密
    ///   - timeout：超时时间，默认为55秒
    /// - Returns:  The created `DataRequest`.
    public func request(url: String,
                        method: LSHTTPMethod = .post,
                        parameters: [String: Any]?,
                        headers: [String: String]? = nil,
                        encoding: ParameterEncoding = URLEncoding.default,
                        isRetry:Bool = false,
                        isEncrypt:Bool=false,
                        timeout: TimeInterval = 55) -> LSRequest {
        
      
        let task = LSRequest()
        
        let reqUrl = addBaseUrl(url)
        
        
        var heads: HTTPHeaders?
        heads = HTTPHeaders()
        //公共header
        commonHeaders(&heads)
        if let tempHeaders = headers {
            for (key, value) in tempHeaders {
                heads?.add(HTTPHeader(name: key, value: value))
            }
        }
        

        var param =  commontParameters(para: parameters)
        if method == .get, parameters==nil {
            param = nil
        }
            let dataRequest = sessionManager.request(reqUrl,
                                                  method: methodWith(method),
                                                  parameters: param,
                                                  encoding: encoding,
                                                  headers: heads,
                                                  interceptor:CustomRequestInterceptor(paramsDict: param, isRetry: isRetry, isEncrypt: isEncrypt, timeoutInterval: timeout, encoding: encoding),
                                                  requestModifier:nil).validate()
            task.request = dataRequest
            if isEncrypt {
                dataRequest.responseString{[weak self] response in
                    debugPrint(response)
                    task.handleResponseString(response: response, isEncrypt: isEncrypt)
                    if let index = self?.taskQueue.firstIndex(of: task) {
                        self?.taskQueue.remove(at: index)
                    }
                   
                }
            }else{
                dataRequest.responseJSON { [weak self] response in
                    task.handleResponse(response: response)
                    debugPrint(response)
                    if let index = self?.taskQueue.firstIndex(of: task) {
                        self?.taskQueue.remove(at: index)
                    }
                }
                
            }

        taskQueue.append(task)
        return task
    }
    /// - Parameters:
    ///   - method: `LSHTTPMethod` for the `URLRequest`. `.post` by default.
    ///   - parameters: [String: String]. `nil` by default.
    ///   - datas: Data to upload. The data is encapsulated here! more see `LSMultipartData`
    ///   - headers: `HTTPHeaders` value to be added to the `URLRequest`. `nil` by default.
    ///
    public func upload(url: String,
                       method: LSHTTPMethod  = .post,
                       parameters: [String: Any]?,
                       datas: [LSMultipartData],
                       headers: [String: String]? = nil,
                       isRetry:Bool = false,
                       timeout: TimeInterval = 55) -> LSRequest {
        let task = LSRequest()

        var h: HTTPHeaders?
        h = HTTPHeaders()
        //公共header
        commonHeaders(&h)
        if let tempHeaders = headers {
            for (key, value) in tempHeaders {
                h?.add(HTTPHeader(name: key, value: value))
            }
            
        }

        task.request = sessionManager.upload(multipartFormData: { [self] (multipartData) in
            // 1.参数 parameters
            if let parameters = commontParameters(para: parameters) {
                for p in parameters {
                    multipartData.append((p.value as! String).data(using: .utf8)!, withName: p.key)
                }
            }
            // 2.数据 datas
            for d in datas {
                multipartData.append(d.data, withName: d.name, fileName: d.fileName, mimeType: d.mimeType)
            }
        }, to: addBaseUrl(url), method: methodWith(method), headers: h,
        interceptor:CustomRequestInterceptor(paramsDict: nil, isRetry: isRetry, isEncrypt: false, timeoutInterval: timeout, encoding: JSONEncoding.default))
        .uploadProgress(queue: .main, closure: { (progress) in
            task.handleProgress(progress: progress)
        }).validate().responseJSON(completionHandler: { [weak self] response in
            task.handleResponse(response: response)

            if let index = self?.taskQueue.firstIndex(of: task) {
                self?.taskQueue.remove(at: index)
            }
        })
        taskQueue.append(task)
        return task
    }
    /// - Parameters:
    ///   - url: String
    ///   - method: LSHTTPMethod
    ///   - parameters: [String: String]
    ///   - headers: [String:Any]
    ///   - timeoutInterval: second
    /// - Returns: The created `DownloadRequest`.
    public func download(url: String,
                         method: LSHTTPMethod = .get,
                         parameters: [String: Any]?,
                         headers: [String: String]? = nil,
                         isRetry:Bool = false,
                         isEncrypt:Bool=false,
                         timeout: TimeInterval = 55) -> LSRequest {
        let task = LSRequest()

        var heads: HTTPHeaders?
        heads = HTTPHeaders()
        //公共header
        commonHeaders(&heads)
        if let tempHeaders = headers {
            if heads == nil{
                heads = HTTPHeaders(tempHeaders)
            }
            for (key, value) in tempHeaders {
                heads?.add(HTTPHeader(name: key, value: value))
            }
            
        }
        let parms = commontParameters(para: parameters)
        task.request = sessionManager.download(addBaseUrl(url),
                                              method: methodWith(method),
                                              parameters: parms,
                                              encoding: URLEncoding.default,
                                              headers: heads,
                                              interceptor:CustomRequestInterceptor(paramsDict: parms, isRetry: isRetry, isEncrypt: isEncrypt, timeoutInterval: timeout, encoding: URLEncoding.default)).downloadProgress{ progress in
                                                task.handleProgress(progress: progress)
                                                debugPrint("下载进度：\(progress)")
                                              }.validate().responseData(completionHandler: { respone in
                                                task.handleDownResponse(response: respone)
                                                debugPrint("下载结果:\(respone)")
                                              })
        
        taskQueue.append(task)
        return task
    }
    private func addBaseUrl(_ url: String) -> String{
        var reqUrl:String?
        //拼接BaseUrl
        if let base = LSNT.config?.baseUrlStr, !url.hasPrefix("http"){
            reqUrl = base
            if !reqUrl!.hasSuffix("/"), !url.hasPrefix("/"){
                reqUrl! += "/"
            }
        }
        
        if reqUrl == nil {
            reqUrl = url
        }else{
            reqUrl! += url
        }
        debugPrint("ls-url:\(reqUrl!)")
        return reqUrl!
    }
    private func commonHeaders(_ heads: inout HTTPHeaders?){
        if let comm = LSNT.config?.commonHeaders() {  //公共header
            for (key, value) in comm {
                heads?.add(name: key, value: value)
            }
            
        }
    }
    private func commontParameters(para:[String:Any]?)->[String:Any]?{
        var parameters:[String:Any]

        if para != nil{
            parameters = para!
        }else {
            parameters = [String:Any]()
        }
        //公参读取
        if let cfg = LSNT.config {
            if let comm = cfg.commonParams() {
                parameters.netMerge(dict: comm)
            }
        }else{
            fatalError(#file + ".config参数不能为空")
        }
        
        return parameters
    }
    
    public func cancelAllRequests(completingOnQueue queue: DispatchQueue = .main, completion: (() -> Void)? = nil) {
        sessionManager.cancelAllRequests(completingOnQueue: queue, completion: completion)
    }
    private func responseFailure(_ error: AFError){
        if let closure = failedHandler {
            var errorMsg = ""
            var errorCode: Int?
            if let nError = error.underlyingError as NSError?, !nError.localizedDescription.isEmpty {
                errorMsg = nError.localizedDescription
                errorCode = nError.code
            }else {
                errorMsg = error.localizedDescription
                errorCode = error.responseCode
            }
            let lsError = LSNetworkingError(code: errorCode ?? -1, desc: errorMsg)
            
            closure(lsError)
        }
    }
    /**
     @brief json字符串转字典
     @author rf/2021-07-02
     */
    func dict(_ jsonStr: String)  throws -> Any{
        let data = jsonStr.data(using: .utf8)
        return try JSONSerialization.jsonObject(with: data!, options: .mutableLeaves)
    }
    // MARK: - Handler
    func handleResponseString(response: AFDataResponse<String>, isEncrypt:Bool=false) {
    
        switch response.result {
            case .failure(let error):
                responseFailure(error)
            case .success(let JSON):
                if JSON.isEmpty{
                    let lsError = LSNetworkingError(code: -1, desc: "未知错误")
                    if let closure = failedHandler {
                        closure(lsError)
                    }
                }else{
                    if let closure = successHandler {
                        if isEncrypt {
                            if let jn = LSNT.config?.commonDecrypt(JSON) {
                                let json = try? dict(jn)
                                closure(json ?? [String:Any]())
                            }else{
                                let json = try? dict(JSON)
                                closure(json ?? [String:Any]())
                            }
                            
                        }else{
                            let json = try? dict(JSON)
                            closure(json ?? [String:Any]())
                        }
                        
                    }
                }
            return
        }
        clearReference()
    }
    
    /// Handle request response
    func handleResponse(response: AFDataResponse<Any>) {
        
        switch response.result {
            case .failure(let error):
                responseFailure(error)
            case .success(let JSON):
                guard let data  = JSON as? NSDictionary else {
                    let lsError = LSNetworkingError(code: -1, desc: "未知错误")
                    if let closure = failedHandler {
                        closure(lsError)
                    }
                    return
                }
                //兼容无code情况
                guard  let code = data.value(forKey: "code") as? Int else {
                    let lsError = LSNetworkingError(code: -1, desc: data.value(forKey: "message") as? String ?? "")
                    if let closure = failedHandler {
                        closure(lsError)
                    }
                    return
                }
                
                
                guard code == 0 else {
                    let lsError = LSNetworkingError(code: code, desc: data.value(forKey: "message") as? String ?? "")
                    if let closure = failedHandler {
                        closure(lsError)
                    }
                    return
                }
                
                if let closure = successHandler {
                    closure(JSON)
                }
                
        }
        clearReference()
    }

    /// Handle requestDown response
    func handleDownResponse(response: AFDownloadResponse<Data>) {
        
        guard let data = response.value else {
            
            if let closure = failedHandler {
                let lsError = LSNetworkingError(code: -1, desc: "Data is empty")
                closure(lsError)
            }
            return
        }
        if let closure = successHandler {
            closure(data)
        }
        clearReference()
    }
    
    /// Processing request progress (Only when uploading files)
    func handleProgress(progress: Foundation.Progress) {
        if let closure = progressHandler {
            closure(progress)
        }
    }

    // MARK: - Callback

    /// Adds a handler to be called once the request has finished.
    ///
    /// - Parameters:
    ///   - closure: A closure to be executed once the request has finished.
    ///   request/upload接口统一返回json字典
    ///   download接口返回 Data
    ///
    /// - Returns:             The request.
    @discardableResult
    public func success(_ closure: @escaping LSSuccessClosure) -> Self {
        successHandler = closure
        return self
    }

    /// Adds a handler to be called once the request has finished.
    ///
    /// - Parameters:
    ///   - closure: A closure to be executed once the request has finished.
    ///
    /// - Returns:             The request.
    @discardableResult
    public func failed(_ closure: @escaping LSFailedClosure) -> Self {
        failedHandler = closure
        return self
    }

    /// Sets a closure to be called periodically during the lifecycle of the instance as data is sent to the server.
    ///
    /// - Note: Only the last closure provided is used.
    ///
    /// - Parameters:
    ///   - closure: The closure to be executed periodically as data is sent to the server.
    ///
    /// - Returns:   The instance.
    @discardableResult
    public func progress(closure: @escaping LSProgressHandler) -> Self {
        progressHandler = closure
        return self
    }


    /// Free memory
    func clearReference() {
        successHandler = nil
        failedHandler = nil
        progressHandler = nil
    }
}
private func methodWith(_ m: LSHTTPMethod) -> Alamofire.HTTPMethod {
    // case delete, get, patch, post, put
    switch m {
    case .delete: return .delete
    case .get: return .get
    case .patch: return .patch
    case .post: return .post
    case .put: return .put
    }
}
/// Equatable for `LSRequest`
extension LSRequest {
    /// Returns a Boolean value indicating whether two values are equal.
    public static func == (lhs: LSRequest, rhs: LSRequest) -> Bool {
        return lhs.request?.id == rhs.request?.id
    }
}

extension Dictionary {
    mutating func netMerge(dict: [Key: Value]){
        for (k, v) in dict {
            updateValue(v, forKey: k)
        }
    }
}
//MARK: 接口取消、恢复
public extension LSRequest{
    /// Cancels the instance. Once cancelled, a `Request` can no longer be resumed or suspended.
    ///
    /// - Returns: The instance.
    func cancel() {
        request?.cancel()
    }
    func resume(){
        request?.resume()
    }
    func suspend(){
        request?.suspend()
    }
}
/**
 @brief 自定义适配与重试机制.
 @property paramsDict 请求参数，包括公参
 @property isRetry  是否开启3次失败重试，开启后，3次重试完毕会收到回调
 @property isEncrypt 是否加密参数  加密后，返回结果自动解密。加解密具体实现在业务层
 @property timeoutInterval  超时秒设置
 @author rf/2021-07-01
 */
 struct CustomRequestInterceptor: RequestInterceptor {
    var paramsDict: [String: Any]?  //请求参数
    var isRetry: Bool   //3次重试是否开启
    var isEncrypt: Bool  //是否参数加密
    var timeoutInterval : TimeInterval
    var encoding: ParameterEncoding
    public func retry(_ request: Request, for session: Session, dueTo error: Error, completion: @escaping (RetryResult) -> Void) {
        if isRetry,request.retryCount < 3{  //每个接口失败，增加3次重试服务. 接口回调会在3次完成后进行
            completion(.retryWithDelay(1))
        } else {
            completion(.doNotRetry)
        }
    }
    public func adapt(_ urlRequest: URLRequest, for session: Session, completion: @escaping (Result<URLRequest, Error>) -> Void) {
        var req = urlRequest
        req.timeoutInterval = timeoutInterval
        
        if (urlRequest.httpBody != nil) {  //原已存在httpBody, 进行httpBody处理
            let jsondata = try? JSONSerialization.data(withJSONObject: paramsDict ?? "", options: [])
            let jsonstr = String(data: jsondata!, encoding: .utf8)
            if isEncrypt { //加密参数，修改httpBody内容
                req.httpBody = LSNT.config?.commonEncrypt(jsonstr).data(using: .utf8)
            }else{
                if let _ = encoding as? JSONEncoding {
                    //application/json格式处理
                    req.httpBody = jsonstr?.data(using: .utf8)
                }
                
            }
        }
        
        completion(.success(req))
    }
}

