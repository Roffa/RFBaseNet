//
//  LSNetwork.swift
//  LSNetwork
//
//  Created by li.zt on 2021/4/28.
//


public let LSNT = LSNetworking.shared
public let LSNTST = LSNetworkStatus.shared

let version = "5.4.3"
