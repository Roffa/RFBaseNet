//
//  ViewController.swift
//  LSNetwork
//
//  Created by li.zt on 04/28/2021.
//  Copyright (c) 2021 li.zt. All rights reserved.
//

import UIKit
import LSPNetwork
//import LSRequestService

//let url = "https://test-api-faq.lanshan.com/"

let token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpbWdVcmwiOiJodHRwczovL2Nkbi1zY2FubmVyLmxhbnNoYW4uY29tL2hlYWQvZGVmYXVsdC5wbmciLCJwYXNzSWQiOiJmYTBkMjRlNGZlNjI0NTU2OTFjNTdiYjU1NTEzOTE0YSIsIm5hbWUiOiLnlKjmiLcxMzIqKioqODMyOSIsImFjY0lkIjoiMTYzNzg1MTkxMGU1MTYxYjFsdE05cyIsImV4cCI6MTYzMzU4NTc4MCwiaWF0IjoxNjI1ODA5NzgwfQ.0_iXsC5nw5AoEM-OnSKe9RELGRAMgH6QJbB75lz_Rw8"

import CryptoSwift
extension Dictionary {
    mutating func netMerge(dict: [Key: Value]){
        for (k, v) in dict {
            updateValue(v, forKey: k)
        }
    }
}


struct ConfigNetDemo: LSConfigNetProtocol{
    let aes_Key = "b79784a829fec55d"
    let aes_iv  = "e165666005912d7c"
    var baseUrlStr: String? = "https://test-api2-office.lanshan.com"
    
    public func commonEncrypt(_ paramStr: String?)->String {
        
        return aes128Encrypt(paramStr!)
    }
    public func commonDecrypt(_ result: String?)->String{
        if let str = result {
            return aes128Decrypt(str)
        }
        return ""
    }
    
    func aes128Encrypt(_ plainText: String) -> String {
        var encryptedText = ""
        do {
            let aes = try AES(key: aes_Key.bytes, blockMode: CBC(iv: aes_iv.bytes), padding: .pkcs5)
            let encrypted = try aes.encrypt(plainText.bytes)
            let encryptedBase64 = encrypted.toBase64()
            encryptedText = encryptedBase64 ?? ""
        } catch  {

        }
        return encryptedText
    }
    
    func aes128Decrypt(_ base64String: String) -> String {
        var decryptedText = ""
        do {
            let aes = try AES(key: aes_Key.bytes, blockMode: CBC(iv: aes_iv.bytes), padding: .pkcs5)
            decryptedText = try base64String.decryptBase64ToString(cipher: aes)
        } catch  {
            
        }
        return decryptedText
    }
}


class ViewController: UIViewController {

    @IBOutlet weak var getBtn: UIButton!
    
    @IBOutlet weak var postBtn: UIButton!
    
    @IBOutlet weak var uploadBtn: UIButton!
   
    @IBOutlet weak var downBtn: UIButton!
    
   
    @IBAction func WriteFile(_ sender: Any) {
        
        let msg = "需要写入的资源"
        let fileName = "ceshi.ott"

        let fileManager = FileManager.default
        let file = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true).first
        let path = file! + "/" + fileName

        fileManager.createFile(atPath: path, contents:nil, attributes:nil)

        let handle = FileHandle(forWritingAtPath:path)
        handle?.write(msg.data(using: String.Encoding.utf8)!)
      
    }
    
    
    @IBAction func changName(_ sender: Any) {
        let changPath = "/file/rename"
        let params = ["uniqueCode": "315BBF99953645189E86604310D5543A","rename":"测试"]

        LSNT.POST(url: changPath, parameters: params,headers: ["Content-Type":"application/x-www-form-urlencoded","token":token],isRetry: false, isEncrypt: true).success { (response) in
            debugPrint("文件名修改成功\(response)")
        }.failed { (error) in
            debugPrint("文件名失败\(error.message)")
        }
    }
    
    @IBAction func getRequest(_ sender: Any) {
        let params = ["projectCode": "officeCCS", "loginSource" : "1"]
        
        LSNT.GET(url: "https://test-api2-office.lanshan.com/user/storage_space", parameters: params, headers: ["token":token], encoding: .urlEncoding).success { (reponse) in
            
        }.failed { (error) in
                
        }
    }
    
    @IBAction func postRequest(_ sender: Any) {
    
//        let fileList = "/file/list" //列表
//        let params = ["uniqueCode": "315BBF99953645189E86604310D5543A"]   //header:["token":token]
        let fileList = "http://test-api-passport.sdqcloud.com/v1/login/wechat" //列表
        let params = ["projectCode": "officeCCS", "loginSource" : "1"]
        LSNT.POST(url: fileList, parameters: params, headers: nil, encoding: .urlEncoding ,isRetry: true, isEncrypt: false).success { (response) in
            debugPrint("列表查询成功\(response)")
        }.failed { (error) in
            debugPrint("列表查询失败\(error.message)")
        }
    }
    
    @IBAction func uploadRequest(_ sender: Any) {
        
        
        let upload_files = "/file/upload_files" //上传文件

        let documentsPathArray = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)

        let documentsPath = documentsPathArray[0]

        let filePath = documentsPath + "/" + "ceshi.ott"

        guard let data = try? Data(contentsOf: URL(fileURLWithPath: filePath)) else { return  }
        

        let datas = [LSMultipartData(data: data, name: "file", fileName: "ceshi.ott",
                                     type: LSDataMimeType.FormData)]
        
        LSNT.UPLOAD(url: upload_files, parameters: nil,headers: ["Content-Type":"multipart/form-data","token":token], datas: datas).success { (response) in
            debugPrint("上传成功\(response)")
        }.progress { (progress) in
            debugPrint("上传进度\(progress)")
        }.failed { (error) in
            debugPrint("上传失败\(error)")
        }
    }
    
    @IBAction func downGetRequest(_ sender: Any) {
        LSNT.DOWN(url: "https://cdn-office.lanshan.com/office_document_test/teamwork/ffc6223c24f34bf19e488df2372ab3cd/45CE74FA8E0D42DDA047EBC0D92834E92063347515.doc", parameters: nil ).success { (response) in
            print(response)
        }.progress { (prg) in
            print(prg)
        }.failed { (error) in
            print(error.message)
        }
        
    }
    
    
    @IBAction func downPostRequset(_ sender: Any) {
        let downPath = "/file/download_file"

        let params = ["uniqueCode": "ffc6223c24f34bf19e488df2372ab3cd"]
        LSNT.DOWN(url: downPath,  parameters: params, method: .post, headers: ["token":token,"Content-Type":"application/x-www-form-urlencoded"]).success { (response) in
            print(response)
        }.progress { (prg) in
            print(prg)
        }.failed { (error) in
            print(error.message)
        }
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LSNT.config = ConfigNetDemo()
        LSNTST.netWorkReachability { status in
            print(status)

        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

