#!/bin/bash
# 更新时间:2021-4-28
# 手动拷贝podspec到私有仓库更新

export LANG=en_US.UTF-8

tip="使用说明：直接git更新私有库推送spec，无lint验证操作，不符合正常流程规范，谨慎使用\n\
1.tag可先行推送，也可在此推送\n\
2.私有库路径有误时可手动设置localSpecGitDir\n\
3.最后spec确认推送前强行关闭或z取消，不会重置私有库修改，需手动删除\n\
4.最后spec确认不输入y会重置私有库修改，已推送tag需要手动处理"
echo -e "\033[34;1m$tip\033[0m"

spec_repo_name="63-lanshan_ios-doc-lsprivatepodspec"

localSpecGitDir="本地spec仓库地址"

git reset --hard
echoError(){
    echo -e "\033[31;1m$1\033[0m"
}
echoNormal(){
    echo -e "\033[32;1m$1\033[0m"
}

spec_file=''
dir_file=$(dirname $0)
cd $dir_file
for file in `ls `
do
  if [[ $file =~ \.podspec$ ]];then
    spec_file=$file
    break
  fi
done

if [ "$spec_file" = "" ];then
    echoError "error:未找到spec文件"
    exit
fi
versionString=`grep -E 's.version.*=' $spec_file`
versionString=${versionString#*\'}
versionString=${versionString%*\'}

spec_filename=${spec_file%.*}

last_tag=$(git describe --tags `git rev-list --tags --max-count=1`)
if [ $? != 0 ]; then
     echoError "没有获取到tag"
fi
echoNormal "-------- 当前项目仓库最新 tag: ${last_tag} -----------------"
echoNormal "-------- 本地podspec tag: ${versionString} -----------------"
echoNormal "新tag:${versionString}(enter确认，手动输入其他终止)"
read newTag

if [ "" == "$newTag" ];then
    newTag=${versionString}
fi

if [ "$versionString" != "$newTag" ];then
    echoError "-----------------已手动终止-----------------"
    exit
fi

if [ "$last_tag" != "$newTag" ];then
    git tag ${newTag}
    git push origin ${newTag}
    if [ $? != 0 ]; then
        echoError "-----------------推送tag失败，请检查网络环境-----------------"
        exit 1
    fi
fi

checkSpecGitDir(){
    if [ -d $spec_git_dir ];then
        echo
        else
        if [ "$1" = "" ]; then
        echoError "未找到spec仓库地址"
        exit 1
        else
        spec_git_dir=$1
        fi
    fi
}

#同级父目录下
spec_git_dir="$(dirname $(pwd))/${spec_repo_name}/"
#不存在可以手动设置
checkSpecGitDir ${localSpecGitDir}
#未找到再找找.cocoapods目录
checkSpecGitDir "${HOME}/.cocoapods/repos/${spec_repo_name}/"
#找不着
checkSpecGitDir ""

spec_content_dir=$spec_git_dir$spec_filename
target_dir=$spec_content_dir'/'$newTag
commitAction="Add"
if [ -d $spec_content_dir ];then
    commitAction="Update"
    else
    mkdir $spec_content_dir
fi
if [ -d $target_dir ];then
    rm -rf $target_dir
fi
mkdir $target_dir
target_file=$target_dir'/'$spec_file
cp $spec_file $target_file

resetSpec(){
    git reset --hard
    tag_dir="${spec_filename}/${newTag}/"
    if [ -d $tag_dir ];then
        rm -rf $tag_dir
    fi
}

cd $spec_git_dir
git pull origin

if [ $? != 0 ]; then
     echoError "-----------------pull spec 仓库失败，请检查网络环境-----------------"
     resetSpec
     exit 1
fi

message="[$commitAction] $spec_filename ($newTag)"
echoNormal "commit内容：$message"
echoNormal "----------------- 是否开始推送新的spec [输入'y'开始] -----------------------"
read answer
if [[ $answer != y ]]; then
    resetSpec
    exit 0
fi

git add -A
if [ $? != 0 ]; then
     echoError "-----------------spec git add失败-----------------"
     resetSpec
     exit 1
fi
git commit -m "$message"
git push origin
if [ $? != 0 ]; then
     echoError "-----------------push spec 仓库失败，请检查网络环境-----------------"
     exit 1
     else
     pod repo update ${spec_repo_name} --verbose
     echoNormal "-----------------push success-----------------"
fi
